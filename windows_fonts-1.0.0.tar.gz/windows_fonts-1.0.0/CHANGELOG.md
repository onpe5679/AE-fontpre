## 1.0.0 - Unreleased

Inital release targeting Windows Vista and Python 3.7+
